AUWAL DIGITAL CREATOR — WEBSITE PORTFOLIO

Files:
- index.html: website structure
- styles.css: responsive modern styling
- script.js: mobile navigation and footer year
- assets/profile.jpg: supplied profile photo
- assets/featured-work.mp4: supplied featured video

PREVIEW:
Open index.html in a modern web browser. Keep the assets folder beside index.html.

PUBLISHING:
Upload the entire auwal-digital-creator folder to a static hosting service. Do not upload only index.html; the assets folder is required.

CONTACT DETAILS INCLUDED:
Phone: 07073797490
WhatsApp: 09154253607
Email: auwalabdullahisunusi7@gmail.com
Country: Nigeria
